# Cambio: Telegram afuera, Slack adentro


**¿Para quién es esto?** Para ti, si pasas todo el día en Slack y quieres hablar con tu cerebro ahí mismo.

**¿Qué reemplazas?** El disparador (trigger), la descarga del audio y las dos respuestas. **El medio se queda igual:** Transcribe, `Ask the brain`, Speak it, ffmpeg y Clean up.

> **Lee esto primero.** Slack, igual que Telegram, tiene que llamar a n8n en una **dirección HTTPS pública**. Si tu bot de Telegram se cae porque se cae el **túnel** (`getWebhookInfo` muestra `last_error_message` y `pending_update_count` subiendo), Slack se cae por la misma razón. En ese caso, arregla el túnel, o usa la guía de WhatsApp (`1-ABREME-PRIMERO.html`), que no necesita una dirección pública.

---

## Antes del prompt: crea la app de Slack (5 minutos, a mano)

1. https://api.slack.com/apps → **Create New App** → From scratch → nombre `My Brain`, tu workspace.
2. **OAuth & Permissions → Bot Token Scopes:** `chat:write`, `files:read`, `files:write`, `im:history`, `im:read`.
3. **App Home →** activa **Messages Tab** y marca *Allow users to send messages*.
4. **Install to Workspace.** Copia el **Bot User OAuth Token** (`xoxb-…`) y, desde **Basic Information**, el **Signing Secret**. Hazlo fuera de cámara.
5. Tu ID de usuario en Slack: tu perfil → ⋯ → **Copy member ID** (`U0…`).

No configures Event Subscriptions todavía. El prompt lo hace cuando ya exista la URL.

---

## El prompt

```text
Explícame cada paso en palabras simples mientras trabajas.
Tengo un workflow de n8n que ya funciona, `09 - Voice ask` (Clase 4): entra una nota de voz de Telegram, se transcribe, pregunto en /webhook/ask, la respuesta se habla en voz alta, y responde con texto más una nota de voz. Quiero lo mismo en un DM de Slack con mi app `My Brain`. No toques `Transcribe`, `Ask the brain`, `Speak it`, `Reassemble the audio` ni `Clean up`.

Fase 1, secretos (nunca los imprimas):
1. Agrega SLACK_BOT_TOKEN, SLACK_SIGNING_SECRET y SLACK_OWNER_ID a `.class-04-private.env` (modo 600, ignorado por git). Léelos con el eco apagado (echo off), igual que lo hace setup-telegram-private.sh. Pásalos al contenedor de n8n con el mismo override de Compose y recrea n8n.
2. En n8n, crea una credencial de Slack API con el nombre exacto `Brain Bot (Slack)` usando el bot token. Pon el token en el portapapeles sin mostrarlo, igual que --copy-token.

Fase 2, el workflow:
3. Duplica `09 - Voice ask` como `09 - Voice ask (Slack)`. El original se queda inactivo.
4. Disparador: un nodo Slack Trigger con la credencial `Brain Bot (Slack)`, evento "Any Event", vigilando los DMs del bot. Dame la URL de PRODUCCIÓN del webhook para pegarla en Slack → Event Subscriptions → Request URL, suscrita al evento del bot `message.im`. Espera mientras Slack la verifica.
5. Guardia `Is this you?`: descarta el evento si tiene `bot_id` o un `subtype` distinto de `file_share` (si no, el bot se responde a sí mismo), o si `event.user` no es $env.SLACK_OWNER_ID. También deduplica por `event_id`: Slack reintenta si no recibe un 200 en 3 segundos, y cada reintento crearía una segunda ejecución.
   NO ADIVINES LA FORMA DEL DATO: activa solo el disparador, envía un clip de voz desde la app de Slack, y lee primero el payload real en el log de ejecución.
6. Audio: un clip de voz de Slack llega en `event.files[0]`, normalmente como audio/mp4 o webm, NO como ogg. Descarga `url_private_download` con `Authorization: Bearer {{ $env.SLACK_BOT_TOKEN }}`. Guárdalo con su extensión real y ajusta solo la entrada de `ogg to mp3`; ffmpeg acepta cualquier entrada.
7. Si no hay archivo, responde "Send me a voice note and I'll answer out loud."
8. Respuesta de texto: el nodo Slack, `message` → `post`, al canal del DM (`event.channel`), con la respuesta y su fuente.
9. Respuesta de voz: sube el ogg de `To a voice note` como archivo al mismo canal con el nodo Slack (subida de archivo, que usa files.getUploadURLExternal + completeUploadExternal). Slack no tiene un tipo "nota de voz" como Telegram; aparece como un archivo de audio que se puede reproducir, y eso es lo esperado.
10. Ningún token, secreto o ID escrito directamente en un nodo. Todo sale de $env o de la credencial.

Fase 3, pruébalo:
11. Un clip de voz mío en el DM → texto + audio.
12. Otro miembro del workspace escribe al bot → cero respuestas, la guardia lo rechaza.
13. Exporta el JSON y busca xoxb-, el secreto y mi ID U0: cero coincidencias.

Al final, una tabla: nodo | tipo | qué hace.
```

---

## Cuando algo sale mal

| Lo que ves | Qué significa | Solución |
|---|---|---|
| Slack: *Your URL didn't respond with the challenge* | El workflow no está activo, o usaste la URL de **prueba** | Actívalo y usa la URL de **producción** |
| Dos respuestas por pregunta | Slack reintentó; no hay deduplicación por `event_id` | Paso 5 |
| El bot se responde a sí mismo | La guardia no filtra `bot_id` | Desactiva, arregla el paso 5 |
| `not_in_channel` / `channel_not_found` | Messages Tab está apagado, o faltan los scopes `im:*` | Pasos 2–3 de la configuración de la app, y luego **reinstala** la app |
| `missing_scope` en la descarga | Falta `files:read` | Agrégalo y reinstala |
| ffmpeg falla con el audio | Asumió ogg | Paso 6: guárdalo con su extensión real |

*El cerebro que dirige una empresa: Clase 4, mejora opcional. Orbix Automation Solutions.*
