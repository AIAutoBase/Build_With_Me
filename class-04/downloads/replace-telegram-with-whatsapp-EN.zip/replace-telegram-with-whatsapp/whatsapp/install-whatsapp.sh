#!/usr/bin/env bash
set -euo pipefail

# Class 4 swap: installs Evolution API (WhatsApp) next to n8n in ~/brain.
# Never prints a secret. Safe to run twice: it reuses what is already there.
case $- in *x*) set +x ;; esac
umask 077

STACK_DIR="${1:-$HOME/brain}"
PRIVATE_FILE=".class-04-private.env"
OVERRIDE_FILE="docker-compose.whatsapp.yml"
EVO_IMAGE="evoapicloud/evolution-api:v2.3.7"
INSTANCE="brain"

say()  { printf '\n\033[1;32m%s\033[0m\n' "$*"; }
fail() { printf '\n\033[1;31mSTOPPED: %s\033[0m\n' "$*" >&2; exit 1; }

cd "$STACK_DIR" 2>/dev/null || fail "I can't find the folder $STACK_DIR. Where is your brain setup?"
[ -f .env ] || fail "There is no .env file in $STACK_DIR. This is not the brain folder."
command -v docker >/dev/null 2>&1 || fail "Docker is not installed or not turned on."
docker compose ps n8n >/dev/null 2>&1 || fail "I don't see the n8n service in this setup."

upsert() { # upsert FILE KEY VALUE, without printing VALUE
  local file="$1" key="$2" value="$3" tmp
  touch "$file"
  tmp="$file.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done = 0 }
    index($0, key "=") == 1 { if (!done) print key "=" value; done = 1; next }
    { print }
    END { if (!done) print key "=" value }
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
  chmod 600 "$file" 2>/dev/null || true
}
field() { awk -F= -v key="$1" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$PRIVATE_FILE" 2>/dev/null || true; }

say "Step 1 of 5 — Your two numbers"
echo "Type the numbers with the country code, ONLY digits. Example (US): 15555551234"
OWNER="$(field BRAIN_OWNER_WA)"
if [ -z "$OWNER" ]; then
  read -r -p "  Your personal number (the one you will text the bot from): " OWNER
fi
BOTNUM="$(field BRAIN_BOT_WA)"
if [ -z "$BOTNUM" ]; then
  read -r -p "  The NEW number for the bot (the second phone / SIM): " BOTNUM
fi
[[ "$OWNER"  =~ ^[1-9][0-9]{9,14}$ ]] || fail "Your personal number does not look right. Digits only, with country code, no + and no spaces."
[[ "$BOTNUM" =~ ^[1-9][0-9]{9,14}$ ]] || fail "The bot's number does not look right. Digits only, with country code."
[ "$OWNER" != "$BOTNUM" ] || fail "The two numbers are the same. The bot needs its OWN number."

KEY="$(field EVOLUTION_API_KEY)"
[ -n "$KEY" ] || KEY="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
DBPASS="$(field EVOLUTION_DB_PASSWORD)"
[ -n "$DBPASS" ] || DBPASS="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"

upsert "$PRIVATE_FILE" BRAIN_OWNER_WA "$OWNER"
upsert "$PRIVATE_FILE" BRAIN_BOT_WA "$BOTNUM"
upsert "$PRIVATE_FILE" EVOLUTION_API_KEY "$KEY"
upsert "$PRIVATE_FILE" EVOLUTION_DB_PASSWORD "$DBPASS"
upsert "$PRIVATE_FILE" EVOLUTION_URL "http://evolution:8080"
upsert "$PRIVATE_FILE" EVOLUTION_INSTANCE "$INSTANCE"
grep -qxF "$PRIVATE_FILE" .gitignore 2>/dev/null || printf '\n%s\n' "$PRIVATE_FILE" >> .gitignore
echo "  Saved in $PRIVATE_FILE (nobody else can read it)."

say "Step 2 of 5 — Getting WhatsApp (Evolution) ready next to n8n"
cat > "$OVERRIDE_FILE" <<YAML
services:
  n8n:
    env_file:
      - $PRIVATE_FILE
  evolution-db:
    image: postgres:16-alpine
    restart: unless-stopped
    environment:
      POSTGRES_USER: evolution
      POSTGRES_PASSWORD: \${EVOLUTION_DB_PASSWORD}
      POSTGRES_DB: evolution
    volumes:
      - evolution_db:/var/lib/postgresql/data
  evolution:
    image: $EVO_IMAGE
    restart: unless-stopped
    depends_on: [evolution-db]
    ports:
      - "127.0.0.1:${EVOLUTION_HOST_PORT:-8080}:8080"
    environment:
      SERVER_URL: http://evolution:8080
      AUTHENTICATION_API_KEY: \${EVOLUTION_API_KEY}
      DATABASE_ENABLED: "true"
      DATABASE_PROVIDER: postgresql
      DATABASE_CONNECTION_URI: postgresql://evolution:\${EVOLUTION_DB_PASSWORD}@evolution-db:5432/evolution?schema=public
      CACHE_REDIS_ENABLED: "false"
      CACHE_LOCAL_ENABLED: "true"
      LOG_LEVEL: ERROR,WARN
    volumes:
      - evolution_instances:/evolution/instances
volumes:
  evolution_db:
  evolution_instances:
YAML
chmod 600 "$OVERRIDE_FILE" 2>/dev/null || true

# Compose reads \${...} from .env, so the two values it interpolates go there too.
upsert .env EVOLUTION_API_KEY "$KEY"
upsert .env EVOLUTION_DB_PASSWORD "$DBPASS"

current="$(awk -F= '$1=="COMPOSE_FILE"{sub(/^[^=]*=/,"");print;exit}' .env)"
if [ -z "$current" ]; then
  for f in compose.yaml compose.yml docker-compose.yaml docker-compose.yml; do
    [ -f "$f" ] && { current="$f"; break; }
  done
  for f in compose.override.yaml compose.override.yml docker-compose.override.yaml docker-compose.override.yml docker-compose.class-04.yml; do
    [ -f "$f" ] && current="$current:$f"
  done
fi
case ":$current:" in *":$OVERRIDE_FILE:"*) ;; *) current="$current:$OVERRIDE_FILE" ;; esac
upsert .env COMPOSE_PATH_SEPARATOR ":"
upsert .env COMPOSE_FILE "$current"

docker compose config --quiet || fail "Docker did not accept the setup. Send a photo of this error to the group (it has no secrets)."

say "Step 3 of 5 — Turning on (the first time it downloads ~500 MB, it may take a few minutes)"
docker compose up -d evolution-db evolution
docker compose up -d --force-recreate n8n

api() { # api METHOD PATH [JSON]
  docker compose exec -T n8n node -e '
    const [m, p, b] = process.argv.slice(1);
    fetch("http://evolution:8080" + p, { method: m,
      headers: { apikey: process.env.EVOLUTION_API_KEY, "content-type": "application/json" },
      body: b || undefined })
      .then(async r => { process.stdout.write(await r.text()); process.exit(r.ok ? 0 : 1); })
      .catch(e => { console.error(e.message); process.exit(2); });
  ' "$@"
}

printf '  Waiting for WhatsApp to wake up'
for _ in $(seq 1 60); do
  api GET / >/dev/null 2>&1 && break
  printf '.'; sleep 3
done
echo
api GET / >/dev/null 2>&1 || fail "Evolution did not answer in 3 minutes. Run: docker compose logs evolution --tail 40"

set_webhook() {
  api POST "/webhook/set/$INSTANCE" '{"webhook":{"enabled":true,"url":"http://n8n:5678/webhook/brain-whatsapp","byEvents":false,"base64":true,"events":["MESSAGES_UPSERT"]}}' >/dev/null
}
is_open() { api GET "/instance/connectionState/$INSTANCE" 2>/dev/null | grep -q '"open"'; }

say "Step 4 of 5 — Creating the bot and connecting it to n8n"
if is_open; then
  set_webhook
  say "Step 5 of 5 — The bot's phone was ALREADY connected. You finished this part!"
  exit 0
fi

# Evolution only returns a pairing code when the number is given at creation time,
# so an unpaired instance is recreated on every run: each run = a fresh code.
api DELETE "/instance/delete/$INSTANCE" >/dev/null 2>&1 || true
CREATED="$(api POST /instance/create "{\"instanceName\":\"$INSTANCE\",\"integration\":\"WHATSAPP-BAILEYS\",\"qrcode\":true,\"groupsIgnore\":true,\"number\":\"$BOTNUM\"}")" \
  || fail "Evolution would not create the bot. Run: docker compose logs evolution --tail 40"
set_webhook
echo "  Done: WhatsApp will tell n8n inside the system, with no internet in between."

pick() { printf '%s' "$CREATED" | docker compose exec -T n8n node -e '
  let s=""; process.stdin.on("data",d=>s+=d).on("end",()=>{
    try { process.stdout.write(String(JSON.parse(s).qrcode[process.argv[1]] || "")) } catch {} })' "$1"; }
CODE="$(pick pairingCode)"
QR="$(pick code)"

say "Step 5 of 5 — Connect the bot's phone"
echo "  On the BOT'S PHONE (the new number):"
echo "    WhatsApp → Settings → Linked devices → Link a device"
if [ -n "$CODE" ]; then
  echo "    → at the bottom: \"Link with phone number instead\""
  echo
  printf '  Type this code:   \033[1;33m%s-%s\033[0m\n' "${CODE:0:4}" "${CODE:4}"
  echo
  echo "  (Code not working? The QR code to scan is below.)"
fi
if [ -n "$QR" ]; then
  echo
  echo "  Or scan this QR code with the camera in \"Link a device\":"
  docker compose exec -T evolution node -e 'require("qrcode").toString(process.argv[1],{type:"terminal",small:true}).then(s=>process.stdout.write(s))' "$QR" \
    || echo "  (I could not draw the QR code here; use the code)"
fi

printf '  Waiting for you to do it (you have ~2 minutes)'
for _ in $(seq 1 40); do
  if is_open; then
    echo; say "CONNECTED! The bot's WhatsApp is ready. Go back to the guide."
    exit 0
  fi
  printf '.'; sleep 3
done
echo
echo "  Not connected yet. That's okay: run this same command again and it will give you a new code."
